import torch
from torch import nn
from torch.functional import F
from functools import reduce
from torchvision.models import resnext50_32x4d

class ResBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, stride, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.skipconv = nn.Conv2d(in_channels, out_channels, 1, stride)
        self.skipbn = nn.BatchNorm2d(out_channels)
        self.do = nn.Dropout(0.4)

    def forward(self, x):
        y = F.relu(self.bn1(self.conv1(x)))
        y = F.relu(self.bn2(self.conv2(y)))
        return self.do(y + self.skipbn(self.skipconv(x)))

class NextSubBlock(nn.Module):
    def __init__(self, channels, bottleneck):
        super(NextSubBlock, self).__init__()
        self.conv1 = nn.Conv2d(channels, bottleneck, 1)
        self.bn1 = nn.BatchNorm2d(bottleneck)
        self.conv2 = nn.Conv2d(bottleneck, bottleneck, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(bottleneck)
        self.conv3 = nn.Conv2d(bottleneck, channels, 1)
        self.bn3 = nn.BatchNorm2d(channels)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.bn3(self.conv3(x))
        return x

class NextBlock(nn.Module):
    def __init__(self, channels, cardinality):
        super(NextBlock, self).__init__()
        self.parallel_blocks = nn.ModuleList(NextSubBlock(channels, 128//cardinality) for i in range(cardinality))

    def forward(self, x):
        return F.relu(reduce(lambda a, b: a + b(x), [x] + list(self.parallel_blocks)))

class ResNext(torch.nn.Module):
    def __init__(self):
        super(ResNext, self).__init__()
        self.conv = nn.Conv2d(3, 64, 7, 2)
        self.bn = nn.BatchNorm2d(64)
        self.max_pool = nn.MaxPool2d(3, 2)
        self.res1 = ResBlock(64, 64, 1)
        self.next1 = NextBlock(64, 32)
        self.next2 = NextBlock(64, 32)
        self.res2 = ResBlock(64, 128, 2)
        self.next3 = NextBlock(128, 32)
        self.next4 = NextBlock(128, 32)
        self.res5_cracks = ResBlock(128, 256, 2)
        self.next5_cracks = NextBlock(256, 32)
        self.next6_cracks = NextBlock(256, 32)
        self.res5_inactives = ResBlock(128, 256, 2)
        self.next5_inactives = NextBlock(256, 32)
        self.next6_inactives = NextBlock(256, 32)
        self.fc_cracks = nn.Linear(256, 1)
        self.fc_inactives = nn.Linear(256, 1)

    def forward(self, x):
        x = x[:, :, 20:-20, 20:-20]
        x = self.max_pool(F.relu(self.bn(self.conv(x))))
        x = self.next2(self.next1(self.res1(x)))
        x = self.next4(self.next3(self.res2(x)))
        x_cracks = self.next6_cracks(self.next5_cracks(self.res5_cracks(x)))
        x_inactives = self.next6_inactives(self.next5_inactives(self.res5_inactives(x)))
        x_cracks = x_cracks.mean(dim=(2, 3))
        x_inactives = x_inactives.mean(dim=(2, 3))

        x_cracks = x_cracks.view(x_cracks.shape[0], -1)
        x_inactives = x_inactives.view(x_inactives.shape[0], -1)

        x_cracks = self.fc_cracks(x_cracks)
        x_inactives = self.fc_inactives(x_inactives)
        return torch.sigmoid(torch.cat([x_cracks, x_inactives], dim=1))

class ResNet(torch.nn.Module):
    def __init__(self):
        super(ResNet, self).__init__()
        self.conv = nn.Conv2d(3, 64, 7, 2)
        self.bn = nn.BatchNorm2d(64)
        self.max_pool = nn.MaxPool2d(3, 2)
        self.res1 = ResBlock(64, 64, 1)
        self.res2 = ResBlock(64, 128, 2)
        self.res4 = ResBlock(128, 256, 2)
        self.res5_cracks = ResBlock(256, 512, 2)
        self.res5_inactives = ResBlock(256, 512, 2)
        self.do_cracks = nn.Dropout(0.2)
        self.do_inactives = nn.Dropout(0.2)
        self.fc_cracks = nn.Linear(512, 1)
        self.fc_inactives = nn.Linear(512, 1)

    def forward(self, x):
        x = self.max_pool(F.relu(self.bn(self.conv(x))))
        x = self.res1(x)
        x = self.res2(x)
        x = self.res4(x)
        x_cracks = self.res5_cracks(x)
        x_inactives = self.res5_inactives(x)
        x_cracks = x_cracks.mean(dim=(2, 3))
        x_inactives = x_inactives.mean(dim=(2, 3))

        x_cracks = x_cracks.view(x_cracks.shape[0], -1)
        x_inactives = x_inactives.view(x_inactives.shape[0], -1)

        x_cracks = self.fc_cracks(self.do_cracks(x_cracks))
        x_inactives = self.fc_inactives(self.do_inactives(x_inactives))
        return torch.sigmoid(torch.cat([x_cracks, x_inactives], dim=1))

class OrigResNext(nn.Module):
    def __init__(self, pretrained=False):
        super(OrigResNext, self).__init__()
        self.rn = resnext50_32x4d(pretrained)
        self.rn.fc = nn.Linear(2048, 2)

    def forward(self, x):
        x = x[:, :, 15:-15, 15:-15]
        return torch.sigmoid(self.rn(x))