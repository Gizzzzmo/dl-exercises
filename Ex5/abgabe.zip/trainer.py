import torch as t
from sklearn.metrics import f1_score
from tqdm.autonotebook import tqdm#
import hashlib


class Trainer:

    def __init__(self,
                 model,                        # Model to be trained.
                 crit,                         # Loss function
                 optim=None,                   # Optimizer
                 train_dl=None,                # Training data set
                 val_test_dl=None,             # Validation (or test) data set
                 cuda=True,                    # Whether to use the GPU
                 early_stopping_patience=-1):  # The patience for early stopping
        self._model = model
        self._crit = crit
        self._optim = optim
        self._train_dl = train_dl
        self._val_test_dl = val_test_dl
        self._cuda = cuda
        self._epoch = 0

        self._early_stopping_patience = early_stopping_patience

        if cuda:
            self._model = model.cuda()
            self._crit = crit.cuda()
            
    def save_checkpoint(self, epoch):
        t.save({'state_dict': self._model.state_dict()}, 'checkpoints/'+hashlib.md5(str(self._model).encode()).hexdigest()+'_best_checkpoint_{:03d}.ckp'.format(epoch))
    
    def restore_checkpoint(self, epoch_n):
        self._epoch = epoch_n
        ckp = t.load('checkpoints/'+hashlib.md5(str(self._model).encode()).hexdigest()+'_best_checkpoint_{:03d}.ckp'.format(epoch_n), 'cuda' if self._cuda else None)
        self._model.load_state_dict(ckp['state_dict'])
        
    def save_onnx(self, fn):
        m = self._model.cpu()
        m.eval()
        x = t.randn(1, 3, 300, 300, requires_grad=True)
        y = self._model(x)
        t.onnx.export(m,                 # model being run
              x,                         # model input (or a tuple for multiple inputs)
              fn,                        # where to save the model (can be a file or file-like object)
              export_params=True,        # store the trained parameter weights inside the model file
              opset_version=10,          # the ONNX version to export the model to
              do_constant_folding=True,  # whether to execute constant folding for optimization
              input_names = ['input'],   # the model's input names
              output_names = ['output'], # the model's output names
              dynamic_axes={'input' : {0 : 'batch_size'},    # variable lenght axes
                            'output' : {0 : 'batch_size'}})
            
    def train_step(self, x, y):
        # perform following steps:
        # -reset the gradients
        # -propagate through the network
        # -calculate the loss
        # -compute gradient by backward propagation
        # -update weights
        # -return the loss
        self._optim.zero_grad()
        pred = self._model(x)
        # print(t.transpose(pred, 0, 1))
        # print(t.transpose(y, 0, 1))
        
        loss = self._crit(pred, y)
        # print(loss)
        loss.backward()
        self._optim.step()
        
        return loss.item()
    
    def val_test_step(self, x, y):
        
        # predict
        # propagate through the network and calculate the loss and predictions
        # return the loss and the predictions
        outputs = self._model(x)
        
        loss = self._crit(outputs, y)
        return loss.item(), outputs > 0.5

    def train_epoch(self):
        # set training mode
        # iterate through the training set
        # transfer the batch to "cuda()" -> the gpu if a gpu is given
        # perform a training step
        # calculate the average loss for the epoch and return it
        self._model.train()

        loss = 0
        samples = 0


        for i, (x, y) in enumerate(tqdm(self._train_dl, ncols=100, ascii=True)):
            if self._cuda:
                x = x.cuda()
                y = y.cuda()
            loss += self.train_step(x, y)
            samples += len(x)

        return loss/samples
    
    def val_test(self, dl=None):
        if dl is None:
            dl = self._val_test_dl
        # set eval mode
        # disable gradient computation
        # iterate through the validation set
        # transfer the batch to the gpu if given
        # perform a validation step
        # save the predictions and the labels for each batch
        # calculate the average loss and average metrics of your choice. You might want to calculate these metrics in designated functions
        # return the loss and print the calculated metrics
        self._model.eval()

        correct_cracks = 0
        correct_inactives = 0
        correct_non_cracks = 0
        correct_non_inactives = 0

        predicted_cracks = 0
        predicted_inactives = 0

        cracks = 0
        inactives = 0

        samples = 0

        with t.no_grad():
            loss = 0

            for x, y in dl:
                if self._cuda:
                    x = x.cuda()
                    y = y.cuda()

                batch_loss, predictions = self.val_test_step(x, y)
                loss += batch_loss
                correct_cracks += ((predictions[:, 0] == 1) * (y[:, 0] == 1)).sum().float()
                correct_inactives += ((predictions[:, 1] == 1) * (y[:, 1] == 1)).sum().float()

                correct_non_cracks += ((predictions[:, 0] == 0) * (y[:, 0] == 0)).sum().float()
                correct_non_inactives += ((predictions[:, 1] == 0) * (y[:, 1] == 0)).sum().float()

                cracks += y[:, 0].sum().float()
                inactives += y[:, 1].sum().float()

                predicted_cracks += predictions[:, 0].sum().float()
                predicted_inactives += predictions[:, 1].sum().float()

                samples += len(predictions)
                
        crack_recall = correct_cracks/cracks
        inactive_recall = correct_inactives/inactives

        crack_precision = correct_cracks/predicted_cracks
        inactive_precision = correct_inactives/predicted_inactives

        crack_f1 = 2 * (crack_precision * crack_recall)/(crack_precision + crack_recall)
        inactive_f1 = 2 * (inactive_precision * inactive_recall)/(inactive_precision + inactive_recall)

        crack_accuracy = (correct_cracks + correct_non_cracks)/samples
        inactive_accuracy = (correct_inactives + correct_non_inactives)/samples
        print(correct_cracks.item(), predicted_cracks.item(), cracks.item(), samples)
        print('crack metrics:')
        print('recall:', crack_recall.item(), 'precision:', crack_precision.item(), 'f1:', crack_f1.item(), 'accuracy:', crack_accuracy.item())
        
        print(correct_inactives.item(), predicted_inactives.item(), inactives.item(), samples)
        print('inactive metrics:')
        print('recall:', inactive_recall.item(), 'precision:', inactive_precision.item(), 'f1:', inactive_f1.item(), 'accuracy:', inactive_accuracy.item())
        
        return loss/samples
        
    
    def fit(self, epochs=-1):
        assert self._early_stopping_patience > 0 or epochs > 0
        # create a list for the train and validation losses, and create a counter for the epoch 
        
        train_losses = []
        validation_losses = []

        epochs += self._epoch
        smallest_loss = float('inf')
        stopping_counter = 0
        while self._epoch != epochs:
            train_losses.append(self.train_epoch())
            print('\n-------------------------------\n')
            validation_losses.append(self.val_test())
            print('')
            print(self._epoch, train_losses[-1], validation_losses[-1])
            print('\n-------------------------------\n')
            if validation_losses[-1] < smallest_loss:
                self.save_checkpoint(self._epoch)
                smallest_loss = validation_losses[-1]
                stopping_counter = 0
            else:
                stopping_counter += 1
                if stopping_counter == self._early_stopping_patience:
                    break
            # stop by epoch number
            # train for a epoch and then calculate the loss and metrics on the validation set
            # append the losses to the respective lists
            # use the save_checkpoint function to save the model (can be restricted to epochs with improvement)
            # check whether early stopping should be performed using the early stopping criterion and stop if so
            # return the losses for both training and validation
            self._epoch += 1
        return train_losses, validation_losses
                    
        
        
        