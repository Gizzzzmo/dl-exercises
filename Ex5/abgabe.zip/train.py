import torch as t
from data import ChallengeDataset
from trainer import Trainer
from matplotlib import pyplot as plt
import numpy as np
import model
import pandas as pd
from sklearn.model_selection import train_test_split

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

batch_size = 15
# load the data from the csv file and perform a train-test-split
# this can be accomplished using the already imported pandas and sklearn.model_selection modules
train_set, val_set = train_test_split(pd.read_csv('data.csv', sep=';'), random_state=0)
# set up data loading for the training and validation set each using t.utils.data.DataLoader and ChallengeDataset objects
train_dl = t.utils.data.DataLoader(ChallengeDataset(train_set, 'train'), batch_size=batch_size)
val_dl = t.utils.data.DataLoader(ChallengeDataset(val_set, 'val'), batch_size=batch_size)

# create an instance of our ResNet model
rn = model.OrigResNext(True)
# set up a suitable loss criterion (you can find a pre-implemented loss functions in t.nn)
# set up the optimizer (see t.optim)
# create an object of type Trainer and set its early stopping criterion
criterion = t.nn.MSELoss()
optimizer = t.optim.Adam(rn.parameters(), lr=1e-4)
print(count_parameters(rn))
trainer = Trainer(rn, criterion, optimizer, train_dl, val_dl, cuda=True, early_stopping_patience=20)
trainer.restore_checkpoint(5)

# go, go, go... call fit on trainer
res = [[], []]#trainer.fit(200)
# plot the results

plt.plot(np.arange(len(res[0])), res[0], label='train loss')
plt.plot(np.arange(len(res[1])), res[1], label='val loss')
plt.yscale('log')
plt.legend()
plt.savefig('losses.png')
